export const TOKEN_KEY = 'tle-token';
export const NOTIFICATIONS_ENABLE_KEY = 'tle-notifications-enable';
