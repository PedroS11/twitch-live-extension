export interface CommonStore {
    loading: boolean;
    loadingMore: boolean;
    loadingMoreFinished: boolean;
}
