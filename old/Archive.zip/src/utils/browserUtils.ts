export const isFirefox = (): boolean => navigator.userAgent.includes('Firefox');
