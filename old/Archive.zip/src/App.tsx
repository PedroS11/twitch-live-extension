import React from 'react';
import { LiveStreamPage } from './views/LiveStreamPage/LiveStreamPage';

function App() {
    return <LiveStreamPage />;
}

export default App;
